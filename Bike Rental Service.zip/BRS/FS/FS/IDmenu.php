<html>
<link rel="shortcut icon" href="icon.png">
<head>
<style>
    .heading
{
	text-align: center;
    color: black;
    text-shadow: 2px 2px white;
    padding-top: 5px;
}
.table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body >
<div class="heading"><h1>Indian Bike Rental Service</h1></div>
<div class="table">
<table border="5" cellspacing="10" align="center">
  <tr>
    <th>Vehical ID</th>
    <th>Vehical Name</th>
  </tr>
  <tr>
    <td>01</td>
    <td>Hero Honda</td>
  </tr>
  <tr>
    <td>02</td>
    <td>Splender</td>
  </tr>
    <tr>
    <td>03</td>
    <td>KTM</td>
  </tr>
    <tr>
    <td>04</td>
    <td>Bajaj Pulsar 150</td>
  </tr>
    <tr>
    <td>05</td>
    <td>Royal Enfield Bullet 350</td>
  </tr>
    <tr>
    <td>06</td>
    <td>Yamaha</td>
  </tr>
    <tr>
    <td>07</td>
    <td>Suzuki Gixxer</td>
  </tr>
    <tr>
    <td>08</td>
    <td>Honda Dio</td>
  </tr>
    <tr>
    <td>09</td>
    <td>TVS Scooty Streak</td>
  </tr>
    <tr>
    <td>10</td>
    <td>Suzuki Let's</td>
  </tr>
    <tr>
    <td>11</td>
    <td>Mahindra Gusto</td>
  </tr>
    <tr>
    <td>12</td>
    <td>TVS Jupiter</td>
  </tr>
    
</table>
</div>
</body>

</html>