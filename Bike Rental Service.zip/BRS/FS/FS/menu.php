<html>
<link rel="shortcut icon" href="icon.png">
<head>
<title>Customers Bookings List</title>
</head>
<style type="text/css" >
.heading
{
	text-align: center;
    color: white;
    text-shadow: 2px 2px black;
    padding-top: 5px;
}

.table
{
    color: white;
    text-shadow: 0.5px 0.5px blue;
}
    
body
{
    background-color: lightgray;    
}

</style>



<body >
<div class="heading"><h1>Indian Bike Rental Service</h1></div>
<div class="table">
<?php
    $f1=file_get_contents('./normaldish.txt');
    $normal = explode("$", $f1);
    array_pop($normal);

    $f2=file_get_contents('./special.txt');
    $special = explode("$", $f2);
    array_pop($special);
?>
    <table border="5" cellspacing="20" align="left">
    <th>Bike</th>
    <tr>
        <td>Vehical ID</td>
        <td>Customer Name</td>
        <td>Rental Price</td>
    </tr>
    <?php
    foreach ($normal as &$value)
    {
        $ro=explode("|",$value);
        ?>
        <tr>
        <td><?php echo($ro[0]); ?></td>
        <td><?php echo($ro[1]); ?></td>
        <td><?php echo($ro[2]); ?></td>
        </tr>
        <?php
    }
    ?>
    </table>
    <table border="5" cellspacing="20" align="right">
    <th>Scooty</th>
    <tr>
        <td>Vehical ID</td>
        <td>Customer Name</td>
        <td>Rental Price</td>
    </tr>
    <?php
    foreach ($special as &$value)
    {
        $ro=explode("|",$value);
        ?>
        <tr>
        <td><?php echo($ro[0]); ?></td>
        <td><?php echo($ro[1]); ?></td>
        <td><?php echo($ro[2]); ?></td>
        </tr>
        <?php
    }
    ?>
    </table>
</div>
</body>

</html>