<html>
<link rel="shortcut icon" href="icon.png">
<head>
<style>
    .heading
{
	text-align: center;
    color: black;
    text-shadow: 2px 2px white;
    padding-top: 5px;
}
.table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body >
<div class="heading"><h1>Indian Bike Rental Service</h1></div>
<div class="table">
<table border="5" cellspacing="10" align="center">
  <tr>
    <th>Employee ID</th>
    <th>Contact detail</th>
  </tr>
  <tr>
    <td>Emp 01</td>
    <td>9952614568</td>
  </tr>
  <tr>
    <td>Emp 02</td>
    <td>8111544466</td>
  </tr>
    <tr>
    <td>Emp 03</td>
    <td>8546446366</td>
  </tr>
    <tr>
    <td>Emp 04</td>
    <td>7846464224</td>
  </tr>
    
</table>
</div>
</body>

</html>